export interface MultiJobsModel {
  readonly title: string;
  readonly description: string;
  readonly jobTagsId: [];
  readonly id: number;
}
