export interface RolesModel {
  readonly id: number;
  readonly role: string;
}
