import { NgModule } from '@angular/core';
import { MultiJobsService } from './multi-jobs.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [MultiJobsService],
  exports: []
})
export class MultiJobsServiceModule {
}
