import { NgModule } from '@angular/core';
import { ProductService } from './product.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ProductService],
  exports: []
})
export class ProductServiceModule {
}
