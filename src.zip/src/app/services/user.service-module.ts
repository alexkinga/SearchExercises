import { NgModule } from '@angular/core';
import { UserService } from './user.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [UserService],
  exports: []
})
export class UserServiceModule {
}
